USE AdventureWorks2017;
GO

-- Make sure to be in SQL Server 2019 compatibility level
ALTER DATABASE AdventureWorks2017 SET COMPATIBILITY_LEVEL = 150;
GO

-- The query below is designed to under-estimate the number of rows,
-- so we will get a too small memory grant.
-- Execute it a few times and look at the actual execution plan

DECLARE @SubsetSize int = 100000;

SELECT   TOP(200)
         SalesOrderID,
         SalesOrderDetailID,
         ProductID,
         UnitPrice,
         OrderQty,
         LineTotal
FROM    (SELECT   TOP(@SubsetSize) *
         FROM     Sales.SalesOrderDetail
         ORDER BY SalesOrderID, SalesOrderDetailID) AS x
ORDER BY LineTotal DESC
OPTION (OPTIMIZE FOR (@SubsetSize = 100));
GO

-- Clear the procedure cache (NEVER DO THIS IN PRODUCTION!!) then re-run the above
DBCC FREEPROCCACHE;
GO


-- Memory Grant Feedback also affects the reserse situation (too high memory grant)

DECLARE @SubsetSize int = 1000;

SELECT   TOP(200)
         SalesOrderID,
         SalesOrderDetailID,
         ProductID,
         UnitPrice,
         OrderQty,
         LineTotal
FROM    (SELECT   TOP(@SubsetSize) *
         FROM     Sales.SalesOrderDetail
         ORDER BY SalesOrderID, SalesOrderDetailID) AS x
ORDER BY LineTotal DESC
OPTION (OPTIMIZE FOR (@SubsetSize = 100000));
GO


-- Let's put the sample query in a stored procedure to allow some further experiments
CREATE OR ALTER PROC dbo.BestSalesFromSubset
           @SubsetSize int
AS
SELECT   TOP(200)
         SalesOrderID,
         SalesOrderDetailID,
         ProductID,
         UnitPrice,
         OrderQty,
         LineTotal
FROM    (SELECT   TOP(@SubsetSize) *
         FROM     Sales.SalesOrderDetail
         ORDER BY SalesOrderID, SalesOrderDetailID) AS x
ORDER BY LineTotal DESC;
GO


-- Let's pretend that in reality, we are dealing with a table that now has 50000 rows.
-- The first time the query executes it optimizes for this number of rows.
EXEC dbo.BestSalesFromSubset @SubsetSize = 50000;

-- However, as time goes by the table grows, and so does the required memory.
-- At one point the growth will result in a slow query due to memory spill:
EXEC dbo.BestSalesFromSubset @SubsetSize = 80000;

-- However, the very next execution of the query this will already be fixed!
EXEC dbo.BestSalesFromSubset @SubsetSize = 80000;
GO


-- The feature is not perfect. What if, due to parameter sensitivity of a SELECT clause,
-- the number of rows varies wildly between executions?
-- With our stored procedure this is easy to mimic (look at first queries, then query 30 and beyond)

EXEC dbo.BestSalesFromSubset @SubsetSize = 2000;
EXEC dbo.BestSalesFromSubset @SubsetSize = 100000;
GO 20
