USE AdventureWorks2017;
GO

CREATE OR ALTER FUNCTION dbo.CustomerDiscount (@CustomerID int)
RETURNS decimal(3,2)
AS
BEGIN;
    DECLARE @TotalSales money, @Discount decimal(3,2);
	SET @TotalSales = (SELECT SUM(SubTotal)
	                   FROM   Sales.SalesOrderHeader
					   WHERE  CustomerID = @CustomerID);

    IF @TotalSales > 2500
	    SET @Discount = 0.1;  -- 10%
	ELSE IF @TotalSales > 100
	    SET @Discount = 0.05; -- 5%
	ELSE SET @Discount = 0;

	RETURN @Discount;
END;
GO

-- Until SQL Server 2017, this was a bad idea
ALTER DATABASE AdventureWorks2017 SET COMPATIBILITY_LEVEL = 140;
GO

-- Show estimated / actual execution plan for a single execution, then timing for 10 executions
SELECT SUM(dbo.CustomerDiscount(c.CustomerID))
FROM   Sales.Customer AS c;

GO 10


-- On SQL Server 2019, the user-defined function is inlined
ALTER DATABASE AdventureWorks2017 SET COMPATIBILITY_LEVEL = 150;
GO

-- Show estimated / actual execution plan for a single execution, then timing for 10 executions
SELECT SUM(dbo.CustomerDiscount(c.CustomerID))
FROM   Sales.Customer AS c;

GO 10


-- Simplest way to verify whether a user-defined function can be inlined
SELECT is_inlineable
FROM   sys.sql_modules
WHERE  object_id = OBJECT_ID('dbo.CustomerDiscount');
GO


-- FROID also works with nested, and even recursive (!!) UDFs
CREATE OR ALTER FUNCTION dbo.TotalAssemblyQty (@ProductAssemblyID int)
RETURNS decimal (8,2)
AS
BEGIN;
    DECLARE @OwnQty decimal (8,2),
	        @CompQty decimal (8,2),
			@TotalQty decimal (8,2);

	-- Get quantity for passed in value
	SET @OwnQty  = (SELECT SUM(PerAssemblyQty)
	                FROM   Production.BillOfMaterials
				    WHERE  ProductAssemblyID = @ProductAssemblyID);

	-- Get quantity for all components
	SET @CompQty = (SELECT SUM(dbo.TotalAssemblyQty(ComponentID))
	                FROM   Production.BillOfMaterials
				    WHERE  ProductAssemblyID = @ProductAssemblyID);

    -- Result is sum of the two
	SET @TotalQty = COALESCE(@OwnQty, 0) + COALESCE(@CompQty, 0);

	RETURN @TotalQty;
END;
GO

-- Let's do this on SQL Server 2017 first
ALTER DATABASE AdventureWorks2017 SET COMPATIBILITY_LEVEL = 140;
GO

SELECT BillOfMaterialsID, dbo.TotalAssemblyQty(ProductAssemblyID)
FROM   Production.BillOfMaterials;
GO

-- Back to the future...
ALTER DATABASE AdventureWorks2017 SET COMPATIBILITY_LEVEL = 150;
GO

SELECT BillOfMaterialsID, dbo.TotalAssemblyQty(ProductAssemblyID)
FROM   Production.BillOfMaterials;
GO
