USE AdventureWorks2017;
GO

-- Create table-valued type to reduce repetition
DROP PROCEDURE IF EXISTS dbo.CountEm;
DROP TYPE IF EXISTS dbo.TabVarDemo;

CREATE TYPE dbo.TabVarDemo
AS TABLE (BusinessEntityID int NOT NULL PRIMARY KEY,
          FirstName nvarchar(50) NOT NULL);
GO

-- Table variables in SQL Server 2017 (and older)
ALTER DATABASE AdventureWorks2017 SET COMPATIBILITY_LEVEL = 140;
GO


-- What is the estimated rowcount? Why?
DECLARE @Tab AS dbo.TabVarDemo;

INSERT INTO @Tab
SELECT BusinessEntityID, FirstName
FROM   Person.Person;

SELECT COUNT(*)
FROM   @Tab;
GO


-- Is that number really always the same?
-- (Estimated plan first, then run, then estimated plan again)
DECLARE @Tab AS dbo.TabVarDemo;

INSERT INTO @Tab
SELECT BusinessEntityID, FirstName
FROM   Person.Person;

SELECT COUNT(*)
FROM   @Tab
OPTION(RECOMPILE);
GO

-- Another interesting one
CREATE OR ALTER PROCEDURE dbo.CountEm
    @InTable dbo.TabVarDemo READONLY
AS
SELECT  COUNT(*)
FROM    @InTable;
GO

DECLARE @Tab AS dbo.TabVarDemo;

INSERT INTO @Tab
SELECT BusinessEntityID, FirstName
FROM   Person.Person;

EXEC dbo.CountEm @Tab;

DELETE TOP(10000) FROM @Tab;

EXEC dbo.CountEm @Tab;
GO


-- Table Variable Deferred Compilation in SQL Server 2019 changes this
ALTER DATABASE AdventureWorks2017 SET COMPATIBILITY_LEVEL = 150;
GO


-- (Estimated plan first, then run, then estimated plan again)
DECLARE @Tab AS dbo.TabVarDemo;

INSERT INTO @Tab
SELECT BusinessEntityID, FirstName
FROM   Person.Person;

SELECT COUNT(*)
FROM   @Tab;
-- NOTE: No OPTION(RECOMPILE) here
GO


-- This example proves that (unlike interleaved execution for table-valued functions)
-- the query gets recompiled on every execution.
DECLARE @Tab AS dbo.TabVarDemo;
DECLARE @n int = RAND() * 10000 + 5000;

INSERT INTO @Tab
SELECT TOP(@n) BusinessEntityID, FirstName
FROM   Person.Person;

SELECT COUNT(*)
FROM   @Tab;
GO


-- Here is how it works in stored procedures
-- (Estimated plan first, then run, then estimated plan again)
DECLARE @Tab AS dbo.TabVarDemo;

INSERT INTO @Tab
SELECT BusinessEntityID, FirstName
FROM   Person.Person;

EXEC dbo.CountEm @Tab;

DELETE TOP(10000) FROM @Tab;

EXEC dbo.CountEm @Tab;
GO


-- There are still no statistics. So what if we add a filter?
DECLARE @Tab AS dbo.TabVarDemo;

INSERT INTO @Tab
SELECT BusinessEntityID, FirstName
FROM   Person.Person;

-- For inequality: assume 30% (same as when we do have statistics and can't sniff the value)
SELECT COUNT(*)
FROM   @Tab
WHERE  BusinessEntityID < 17;

-- For equality: assume SQRT(Table cardinality)
SELECT COUNT(*)
FROM   @Tab
WHERE  FirstName = 'xyz';

-- But do take known constraints into account
SELECT COUNT(*)
FROM   @Tab
WHERE  BusinessEntityID = 17;
GO
